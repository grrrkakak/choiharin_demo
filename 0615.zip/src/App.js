//수정사항 없음
import React, { useState } from "react";
import "./App.css";
import UserCardResult from "./UserCardResult";
import NearbyPlaces from "./MapInformation";

function App() {
  const [selectedPlace, setSelectedPlace] = useState(null);

  const handlePlaceSelect = (place) => {
    setSelectedPlace(place);
  };

  return (
    <div className="App">
        <NearbyPlaces handlePlaceSelect={handlePlaceSelect} /> 
    </div>
  );
}

export default App;